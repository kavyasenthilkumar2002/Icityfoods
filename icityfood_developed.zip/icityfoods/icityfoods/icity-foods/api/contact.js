const ICITY_EMAIL = 'icityindia@gmail.com'
const CONTACT_FORM_SENDER_NAME = 'FormSubmit'

function buildContactTemplateParams({ name, email, phone, message }) {
  const trimmedName = name.trim()
  const trimmedEmail = email.trim()
  const trimmedPhone = phone?.trim() || ''
  const trimmedMessage = message.trim()

  return {
    from_name: CONTACT_FORM_SENDER_NAME,
    name: trimmedName,
    customer_name: trimmedName,
    user_name: trimmedName,
    email: trimmedEmail,
    user_email: trimmedEmail,
    from_email: trimmedEmail,
    reply_to: trimmedEmail,
    message: trimmedMessage,
    phone: trimmedPhone,
    title: `ICITY Foods — message from ${trimmedName}`,
    to_email: ICITY_EMAIL,
    subject: `ICITY Foods — contact from ${trimmedName}`,
  }
}

function getEmailJsConfig() {
  return {
    serviceId: process.env.EMAILJS_SERVICE_ID || process.env.VITE_EMAILJS_SERVICE_ID,
    templateId: process.env.EMAILJS_TEMPLATE_ID || process.env.VITE_EMAILJS_TEMPLATE_ID,
    publicKey: process.env.EMAILJS_PUBLIC_KEY || process.env.VITE_EMAILJS_PUBLIC_KEY,
  }
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    return res.status(204).end()
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const { serviceId, templateId, publicKey } = getEmailJsConfig()

  if (!serviceId || !templateId || !publicKey) {
    return res.status(503).json({ error: 'Email service not configured on server' })
  }

  const { name, email, phone, message } = req.body || {}

  if (!name?.trim() || !email?.trim() || !message?.trim()) {
    return res.status(400).json({ error: 'Missing required fields' })
  }

  try {
    const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: serviceId,
        template_id: templateId,
        user_id: publicKey,
        template_params: buildContactTemplateParams({
          name: name.trim(),
          email: email.trim(),
          phone: phone?.trim() || '',
          message: message.trim(),
        }),
      }),
    })

    const body = await response.text()

    if (!response.ok) {
      return res.status(502).json({
        error: body || 'Unable to send email',
      })
    }

    return res.status(200).json({ success: true })
  } catch {
    return res.status(502).json({ error: 'Failed to reach email service' })
  }
}
