import fs from 'node:fs/promises'
import path from 'node:path'
import sharp from 'sharp'

const assetsDir = path.resolve('src/assets')
const files = (await fs.readdir(assetsDir)).filter((f) => /\.(png|jpe?g)$/i.test(f))

const results = []
let beforeTotal = 0
let afterTotal = 0

for (const file of files) {
  const filePath = path.join(assetsDir, file)
  const before = (await fs.stat(filePath)).size
  beforeTotal += before

  const image = sharp(filePath)
  const meta = await image.metadata()
  const ext = path.extname(file).toLowerCase()

  let output
  if (ext === '.jpg' || ext === '.jpeg') {
    output = await image.jpeg({ quality: 82, mozjpeg: true }).toBuffer()
  } else {
    output = await image.png({ quality: 82, compressionLevel: 9, palette: meta.width <= 512 }).toBuffer()
  }

  if (output.length < before) {
    const tempPath = `${filePath}.tmp`
    await fs.writeFile(tempPath, output)
    await fs.rename(tempPath, filePath)
    afterTotal += output.length
    results.push({ file, before, after: output.length, saved: before - output.length })
  } else {
    afterTotal += before
    results.push({ file, before, after: before, saved: 0, skipped: true })
  }
}

results.sort((a, b) => b.saved - a.saved)
for (const r of results) {
  const pct = r.before ? ((r.saved / r.before) * 100).toFixed(1) : '0.0'
  console.log(`${r.skipped ? '[keep]' : '[ok]  '} ${r.file}: ${(r.before / 1024).toFixed(1)} KB -> ${(r.after / 1024).toFixed(1)} KB (${pct}% saved)`)
}

console.log('\n---')
console.log(`Files: ${files.length}`)
console.log(`Before: ${(beforeTotal / 1024 / 1024).toFixed(2)} MB`)
console.log(`After:  ${(afterTotal / 1024 / 1024).toFixed(2)} MB`)
console.log(`Saved:  ${((beforeTotal - afterTotal) / 1024 / 1024).toFixed(2)} MB`)
