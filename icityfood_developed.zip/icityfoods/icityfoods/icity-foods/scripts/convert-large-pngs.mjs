import fs from 'node:fs/promises'
import path from 'node:path'
import sharp from 'sharp'

const root = process.cwd()
const assetsDir = path.join(root, 'src/assets')
const srcDir = path.join(root, 'src')
const minBytes = 120 * 1024
const maxDimension = 1200
const jpegQuality = 80

const converted = []

async function walk(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true })
  const files = []
  for (const entry of entries) {
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) files.push(...await walk(full))
    else files.push(full)
  }
  return files
}

for (const file of await fs.readdir(assetsDir)) {
  if (!/\.png$/i.test(file)) continue
  const filePath = path.join(assetsDir, file)
  const before = (await fs.stat(filePath)).size
  if (before < minBytes) continue

  const image = sharp(filePath)
  const meta = await image.metadata()
  const resize =
    meta.width > maxDimension || meta.height > maxDimension
      ? {
          width: meta.width >= meta.height ? maxDimension : undefined,
          height: meta.height > meta.width ? maxDimension : undefined,
          fit: 'inside',
          withoutEnlargement: true,
        }
      : null

  let pipeline = image
  if (resize) pipeline = pipeline.resize(resize)
  const output = await pipeline.jpeg({ quality: jpegQuality, mozjpeg: true }).toBuffer()

  const jpgName = file.replace(/\.png$/i, '.jpg')
  const jpgPath = path.join(assetsDir, jpgName)
  await fs.writeFile(jpgPath, output)
  await fs.unlink(filePath)

  converted.push({
    from: file,
    to: jpgName,
    before,
    after: output.length,
  })
}

for (const file of await walk(srcDir)) {
  if (!/\.(jsx?|tsx?)$/.test(file)) continue
  let content = await fs.readFile(file, 'utf8')
  let changed = false
  for (const { from, to } of converted) {
    const next = content.replaceAll(`/${from}'`, `/${to}'`).replaceAll(`/${from}"`, `/${to}"`)
    if (next !== content) {
      content = next
      changed = true
    }
  }
  if (changed) await fs.writeFile(file, content, 'utf8')
}

converted.sort((a, b) => b.before - a.before - (a.after - b.after))
for (const item of converted) {
  const saved = ((item.before - item.after) / item.before * 100).toFixed(1)
  console.log(`${item.from} -> ${item.to}: ${(item.before / 1024).toFixed(1)} KB -> ${(item.after / 1024).toFixed(1)} KB (${saved}% saved)`)
}

const beforeTotal = converted.reduce((sum, item) => sum + item.before, 0)
const afterTotal = converted.reduce((sum, item) => sum + item.after, 0)
console.log('\n---')
console.log(`Converted: ${converted.length} files`)
console.log(`Saved: ${((beforeTotal - afterTotal) / 1024 / 1024).toFixed(2)} MB`)
