import { Link } from 'react-router-dom'
import logoImg from '../assets/logo.png'

export default function Logo({ className = '' }) {
  return (
    <Link to="/" className={`inline-flex items-center ${className}`}>
      <img
        src={logoImg}
        alt="ICITY Foods"
        className="h-10 w-auto object-contain sm:h-11"
      />
    </Link>
  )
}
