import { Link, useLocation, useNavigate } from 'react-router-dom'
import { ChevronRight, Mail, MapPin, Phone } from 'lucide-react'
import Logo from './Logo'
import {
  ICITY_EMAIL,
  ICITY_EMAIL_WEB_COMPOSE,
  ICITY_GOOGLE_MAPS_URL,
  openBrowserEmailCompose,
} from '../constants/contact'
import { PAGE_BANNER_HASH, scrollToPageBanner } from '../lib/scrollToPageBanner'

const quickLinks = [
  { to: '/', label: 'Home' },
  { to: '/our-story', label: 'Our Story' },
  { to: '/menu', label: 'Menu' },
  { to: '/contact', label: 'Contact' },
]

const ADDRESS =
  'No. 09, Om Ganesh Nagar, 3rd Cross East, Vadavalli, Coimbatore – 641041, India'

function FacebookIcon({ className = 'h-[17px] w-[17px]' }) {
  return (
    <span className={`font-sans text-base font-bold leading-none ${className}`} aria-hidden>
      f
    </span>
  )
}

function InstagramIcon({ className = 'h-[17px] w-[17px]' }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
      <rect x="2" y="2" width="20" height="20" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  )
}

function LinkedInIcon({ className = 'h-[17px] w-[17px]' }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  )
}

function WhatsAppIcon({ className = 'h-[17px] w-[17px]' }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.435 9.884-9.881 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}

const socialLinks = [
  {
    icon: FacebookIcon,
    href: 'https://www.facebook.com/icityinc.cbe/',
    label: 'Facebook',
    hoverClass: 'hover:bg-[#1877F2] hover:text-white',
  },
  {
    icon: InstagramIcon,
    href: 'https://www.instagram.com/icityinc.cbe/',
    label: 'Instagram',
    hoverClass: 'hover:bg-[#E4405F] hover:text-white',
  },
  {
    icon: LinkedInIcon,
    href: 'https://www.linkedin.com/in/abarnagowrishankar-icityinc/',
    label: 'LinkedIn',
    hoverClass: 'hover:bg-[#0A66C2] hover:text-white',
  },
  {
    icon: WhatsAppIcon,
    href: 'https://api.whatsapp.com/send/?phone=918098431431&text=Hello%21+Welcome+to+iCitya+Co-Working+Space+%E2%80%94+we%27re+glad+you+reached+out.+How+can+we+help+you+today%3F&type=phone_number&app_absent=0',
    label: 'WhatsApp',
    hoverClass: 'hover:bg-[#25D366] hover:text-white',
  },
]

function handleFooterEmailClick(e) {
  e.preventDefault()
  openBrowserEmailCompose()
}

function FooterQuickLink({ to, label }) {
  const location = useLocation()
  const navigate = useNavigate()

  const handleClick = (e) => {
    e.preventDefault()

    if (location.pathname === to) {
      scrollToPageBanner()
      return
    }

    navigate(`${to}${PAGE_BANNER_HASH}`)
  }

  return (
    <Link to={to} onClick={handleClick} className="icity-footer__link">
      <ChevronRight className="icity-footer__link-chevron" strokeWidth={2.5} aria-hidden />
      {label}
    </Link>
  )
}

function FooterLeafBadge() {
  return (
    <span className="icity-footer__leaf" aria-hidden>
      <svg viewBox="0 0 24 24" fill="none" className="h-3.5 w-3.5">
        <path
          d="M12 3c-4 6-4 10 0 14 4-4 4-8 0-14z"
          fill="currentColor"
        />
        <path
          d="M8 8c-3 2-3 5 0 8M16 8c3 2 3 5 0 8"
          stroke="currentColor"
          strokeWidth="1.15"
          strokeLinecap="round"
          opacity="0.75"
        />
      </svg>
    </span>
  )
}

export default function Footer() {
  return (
    <footer className="icity-footer mt-auto">
      <div className="icity-footer__main section-container">
        <div className="icity-footer__grid">
          <div className="icity-footer__brand icity-footer__col">
            <div className="icity-footer__logo">
              <Logo />
            </div>
            <p className="icity-footer__tagline">
              Serving fresh flavors and culinary creativity every day.
            </p>
            <div className="icity-footer__socials">
              {socialLinks.map(({ icon: Icon, href, label, hoverClass }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`icity-footer__social-btn ${hoverClass}`}
                >
                  <Icon />
                </a>
              ))}
            </div>
          </div>

          <div className="icity-footer__col icity-footer__col--links">
            <h3 className="icity-footer__heading">Quick Links</h3>
            <ul className="icity-footer__links">
              {quickLinks.map((link) => (
                <li key={link.to}>
                  <FooterQuickLink to={link.to} label={link.label} />
                </li>
              ))}
            </ul>
          </div>

          <div className="icity-footer__col icity-footer__col--contact">
            <h3 className="icity-footer__heading">Contact Us</h3>
            <ul className="icity-footer__contact-list">
              <li>
                <a href="tel:+918086431431" className="icity-footer__contact-row">
                  <span className="icity-footer__contact-icon">
                    <Phone className="h-4 w-4" strokeWidth={1.75} aria-hidden />
                  </span>
                  +91-80984 31431
                </a>
              </li>
              <li>
                <a
                  href={ICITY_EMAIL_WEB_COMPOSE}
                  onClick={handleFooterEmailClick}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="icity-footer__contact-row icity-footer__contact-row--email"
                  aria-label={`Email ICITY Foods at ${ICITY_EMAIL} (opens in browser)`}
                >
                  <span className="icity-footer__contact-icon" aria-hidden>
                    <Mail className="h-4 w-4" strokeWidth={1.75} />
                  </span>
                  <span>{ICITY_EMAIL}</span>
                </a>
              </li>
              <li>
                <span className="icity-footer__contact-row icity-footer__contact-row--static">
                  <a
                    href={ICITY_GOOGLE_MAPS_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="icity-footer__contact-icon"
                    aria-label="Open ICITY Foods location in Google Maps"
                  >
                    <MapPin className="h-4 w-4" strokeWidth={1.75} aria-hidden />
                  </a>
                  <span className="icity-footer__contact-text">{ADDRESS}</span>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="icity-footer__bottom section-container">
        <div className="icity-footer__bottom-rule">
          <FooterLeafBadge />
        </div>
        <p className="icity-footer__copyright">
          &copy; Designed by Icity Foods. &copy; icity Foods 2025. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
