import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import ContactForm from '../components/ContactForm'
import contactUsBannerImg from '../assets/contactusbanner.jpg'
import PageBanner from '../components/PageBanner'

const M = motion

const mapEmbedSrc =
  'https://www.google.com/maps?q=Icity+Inc+Best+Shared+Office+Space+Vadavalli+Coimbatore&output=embed'

export default function Contact() {
  return (
    <>
      <PageBanner
        imageSrc={contactUsBannerImg}
        fullWidth
        imageFit="cover"
        bannerClassName="contact-banner"
        align="right"
        imageFocus="left"
        animateFrom="right"
        contentClassName="contact-banner__copy"
      >
        <h1 className="hero-title">
          <span className="text-icity-gold">Contact </span>
          <span className="text-black">Us</span>
        </h1>
        <div className="flex w-full flex-wrap items-center justify-end gap-[clamp(0.5rem,1.5vw,0.75rem)]">
          <a
            href="tel:+918086431431"
            className="btn-pill-primary"
          >
            Call us
          </a>
          <Link to="/menu" className="btn-pill-secondary">
            Menu
          </Link>
        </div>
      </PageBanner>

      <ContactForm />

      {/* Map */}
      <section className="bg-white px-4 pb-12 pt-4 sm:px-6">
        <M.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mx-auto max-w-7xl overflow-hidden rounded-2xl shadow-md"
        >
          <iframe
            title="ICITY Foods location"
            src={mapEmbedSrc}
            width="100%"
            height="420"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="aspect-[4/3] w-full min-h-[220px] sm:aspect-auto sm:min-h-[320px] md:h-[420px]"
          />
        </M.div>
      </section>
    </>
  )
}
