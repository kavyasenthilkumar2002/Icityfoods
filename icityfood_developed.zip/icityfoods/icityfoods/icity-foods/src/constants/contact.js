export const ICITY_EMAIL = 'icityindia@gmail.com'

/** Shown as the sender name in inbox (EmailJS template → From Name: {{from_name}}) */
export const CONTACT_FORM_SENDER_NAME = 'FormSubmit'

export const ICITY_GOOGLE_MAPS_URL =
  'https://www.google.com/maps/place/Icity+Co-working+Space+,+Private+Offices+%26+Meeting+Rooms/@11.023447,76.907513,16z/data=!4m6!3m5!1s0x3ba85f1d25389f75:0x9d93fcc49fcc15c6!8m2!3d11.0234471!4d76.9075129!16s%2Fg%2F11h3v6lpps?hl=en-US&entry=ttu'

/** Gmail compose in the browser — avoids desktop Outlook opening via mailto: */
export const ICITY_EMAIL_WEB_COMPOSE = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(ICITY_EMAIL)}`

export function openBrowserEmailCompose() {
  window.open(ICITY_EMAIL_WEB_COMPOSE, '_blank', 'noopener,noreferrer')
}
